package com.example.smartgarden1.ui.map;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.smartgarden1.R;
import com.example.smartgarden1.ui.map.MapsActivity;

public class MapFragment extends Fragment {



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        new MapsActivity();
        View root = inflater.inflate(R.layout.activity_maps, container, false);


        return root;
    }
}
